using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class study725 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        // ------------------------------------------�ڷ���(LIST)--------------------------------------------//
        //List<int> list = new List<int>() { 4, 2, 0, 1, 3 };

        //showdata(listtest2(list));
        //showdata(listtest3(list));

        // ----------------------------------------- Dictionary ( )--------------------------------------------//
        Dictionary<int, string> dicString = new Dictionary<int, string>();
        dicString.Add(1000, "���ҵ�");
        dicString.Add(1, "�ռҵ�");

        Debug.Log(dicString[1000]);


    }

    //list 0-10, �ȿ� data�� 10-0 -> �Լ� ¥����

    private List<int> listtest1(List<int> _ilist)
    {
        _ilist.Sort(); // �ش� �ڵ� �ƴ�
        return _ilist;
    }

    //��������
    private List<int> listtest2(List<int> _ilist)
    {
        _ilist.Sort();
        return _ilist;
    }

    //��������
    private List<int> listtest3(List<int> _ilist)
    {
        //List<int> list2 = new List<int>();

        _ilist.Sort();
        _ilist.Reverse();

        return _ilist;
    }
    
    //Debug.Log �Լ�
    private void showdata(List<int> _ilist)
    {
        int count = _ilist.Count;// ���� data�� �����  count ����
        string debugValue = string.Empty;
        for (int iNum = 0; iNum < count; iNum++)
        {
            debugValue +=  _ilist[iNum];
        }
        Debug.Log(debugValue);
    }
}
