using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Study717 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //������
        /*for (int iaNum = 1; iaNum < 10; iaNum++)
        {
            for (int ibNum = 1; ibNum < 10; ibNum++)
            {
                Debug.Log($"{iaNum} x {ibNum} = {iaNum*ibNum}");
            }
        }
        //¦���� ���
        for (int iaNum = 0; iaNum < 10; iaNum = iaNum + 2)
        {
            Debug.Log(iaNum);
        }
        
        //break �� continue ���
        for(int i = 0; i < 10; i++)
        {
            if (i < 5)
            {
                continue;
            }
            
            Debug.Log(i);

        for(int i = 0; i < 10; i++)
        {
            if (i == 5)
            {
                break;
            }
            
            Debug.Log(i);
        }

        //while��
        //�ʱ�� �������� ����, ������ �������� ����
        int value = 0;

        while (value < 10)
        {
            Debug.Log(value++);
        }
        string a = "*";

        for(int i = 1; i < 6 ; i++) //12345
        {
            Debug.Log($"");
        }*/    
    }
}
