using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Study718 : MonoBehaviour
{
    // Start is called before the first frame update
    /*void Start()
    {
        string star = "*";

        for (int i = 0; i < 5; i++)
        {
            star = "*";

            for (int j = 0; j < i; j++)
            {
                star = star + "*";
            }
            Debug.Log(star);

        }
    }*/
    /*void Start()
    {
        string sValue = "\"�����ٶ�\"";

        Debug.Log(sValue + "\n" + sValue + "\n" + sValue + "\n" + sValue);
        

    }*/
    /*

    private int closeValue;
    public int openValue;

    void Start()

    
    {
        //�Լ���?
        int value = 1;
        int reValue = function_add(value);

        Debug.Log(reValue);


    }
    public int function_add(int _ivalue)
  //�Լ�             �Ű�����
    {
        int sum = _ivalue + 3;
        return sum;
    }
    void Start()
    {
        

    }

    /// <summary>
    /// ���̰���������
    /// </summary>
    /// <param name="_ivalue">1234</param>
    /// <returns></returns>
    public int function_add(int _ivalue)
    //�Լ�             �Ű�����
    {
        int sum = _ivalue + 3;
        return sum;
    }*/

    void Start()
    {
        function_sum(1,1);
    }

    public int function_sum(int _iaValue, int _ibValue)
    {
        return _iaValue + _ibValue;
    }

    public float function_sum(float _iaValue, float _ibValue)
    {
        return _iaValue + _ibValue;
    }

}

