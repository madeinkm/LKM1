using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Study7182 : MonoBehaviour
{
    public Study718 m_study;
   // private int value = 0;
    //int value2 = 0;

    
    // Start is called before the first frame update
    void Start()
    {

    

        //int sumvalue = m_study.function_add(10);
        //Debug.Log(sumvalue);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
